﻿using MediatR;

namespace $rootnamespace$.$fileinputname$;

public class $fileinputname$CommandHandler : IRequestHandler<$fileinputname$Command>
{
    public async Task Handle($fileinputname$Command request, CancellationToken cancellationToken)
{
}
}
