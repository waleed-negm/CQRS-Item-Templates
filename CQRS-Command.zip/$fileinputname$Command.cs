﻿using MediatR;

namespace $rootnamespace$.$fileinputname$;

public class $safeitemname$ : IRequest
{
}
