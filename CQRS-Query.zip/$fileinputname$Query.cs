﻿using MediatR;

namespace $rootnamespace$.$fileinputname$;

public class $fileinputname$Query : IRequest
{
}
