﻿using MediatR;

namespace $rootnamespace$.$fileinputname$;

public class $fileinputname$QueryHandler : IRequestHandler<$fileinputname$Query>
{
    public async Task Handle($fileinputname$Query request, CancellationToken cancellationToken)
{
}
}
